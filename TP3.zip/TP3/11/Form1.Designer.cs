﻿namespace _11
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.b1 = new System.Windows.Forms.Button();
            this.b2 = new System.Windows.Forms.Button();
            this.b3 = new System.Windows.Forms.Button();
            this.b4 = new System.Windows.Forms.Button();
            this.b5 = new System.Windows.Forms.Button();
            this.b6 = new System.Windows.Forms.Button();
            this.b7 = new System.Windows.Forms.Button();
            this.b8 = new System.Windows.Forms.Button();
            this.b9 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.labelTurnos = new System.Windows.Forms.Label();
            this.labelMovimientos = new System.Windows.Forms.Label();
            this.buttonPlay = new System.Windows.Forms.Button();
            this.labelJugador = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // b1
            // 
            this.b1.Location = new System.Drawing.Point(107, 54);
            this.b1.Name = "b1";
            this.b1.Size = new System.Drawing.Size(71, 74);
            this.b1.TabIndex = 0;
            this.b1.UseVisualStyleBackColor = true;
            this.b1.Click += new System.EventHandler(this.button_Click);
            // 
            // b2
            // 
            this.b2.Location = new System.Drawing.Point(221, 54);
            this.b2.Name = "b2";
            this.b2.Size = new System.Drawing.Size(71, 74);
            this.b2.TabIndex = 1;
            this.b2.UseVisualStyleBackColor = true;
            this.b2.Click += new System.EventHandler(this.button_Click);
            // 
            // b3
            // 
            this.b3.Location = new System.Drawing.Point(336, 54);
            this.b3.Name = "b3";
            this.b3.Size = new System.Drawing.Size(71, 74);
            this.b3.TabIndex = 2;
            this.b3.UseVisualStyleBackColor = true;
            this.b3.Click += new System.EventHandler(this.button_Click);
            // 
            // b4
            // 
            this.b4.Location = new System.Drawing.Point(107, 184);
            this.b4.Name = "b4";
            this.b4.Size = new System.Drawing.Size(71, 74);
            this.b4.TabIndex = 3;
            this.b4.UseVisualStyleBackColor = true;
            this.b4.Click += new System.EventHandler(this.button_Click);
            // 
            // b5
            // 
            this.b5.Location = new System.Drawing.Point(221, 184);
            this.b5.Name = "b5";
            this.b5.Size = new System.Drawing.Size(71, 74);
            this.b5.TabIndex = 4;
            this.b5.UseVisualStyleBackColor = true;
            this.b5.Click += new System.EventHandler(this.button_Click);
            // 
            // b6
            // 
            this.b6.Location = new System.Drawing.Point(336, 184);
            this.b6.Name = "b6";
            this.b6.Size = new System.Drawing.Size(71, 74);
            this.b6.TabIndex = 5;
            this.b6.UseVisualStyleBackColor = true;
            this.b6.Click += new System.EventHandler(this.button_Click);
            // 
            // b7
            // 
            this.b7.Location = new System.Drawing.Point(107, 308);
            this.b7.Name = "b7";
            this.b7.Size = new System.Drawing.Size(71, 74);
            this.b7.TabIndex = 6;
            this.b7.UseVisualStyleBackColor = true;
            this.b7.Click += new System.EventHandler(this.button_Click);
            // 
            // b8
            // 
            this.b8.Location = new System.Drawing.Point(221, 308);
            this.b8.Name = "b8";
            this.b8.Size = new System.Drawing.Size(71, 74);
            this.b8.TabIndex = 7;
            this.b8.UseVisualStyleBackColor = true;
            this.b8.Click += new System.EventHandler(this.button_Click);
            // 
            // b9
            // 
            this.b9.Location = new System.Drawing.Point(336, 308);
            this.b9.Name = "b9";
            this.b9.Size = new System.Drawing.Size(71, 74);
            this.b9.TabIndex = 8;
            this.b9.UseVisualStyleBackColor = true;
            this.b9.Click += new System.EventHandler(this.button_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(575, 80);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Turno";
            // 
            // labelTurnos
            // 
            this.labelTurnos.AutoSize = true;
            this.labelTurnos.Location = new System.Drawing.Point(646, 80);
            this.labelTurnos.Name = "labelTurnos";
            this.labelTurnos.Size = new System.Drawing.Size(0, 13);
            this.labelTurnos.TabIndex = 10;
            // 
            // labelMovimientos
            // 
            this.labelMovimientos.AutoSize = true;
            this.labelMovimientos.Location = new System.Drawing.Point(669, 129);
            this.labelMovimientos.Name = "labelMovimientos";
            this.labelMovimientos.Size = new System.Drawing.Size(0, 13);
            this.labelMovimientos.TabIndex = 12;
            // 
            // buttonPlay
            // 
            this.buttonPlay.Location = new System.Drawing.Point(591, 324);
            this.buttonPlay.Name = "buttonPlay";
            this.buttonPlay.Size = new System.Drawing.Size(118, 42);
            this.buttonPlay.TabIndex = 13;
            this.buttonPlay.Text = "Jugar";
            this.buttonPlay.UseVisualStyleBackColor = true;
            this.buttonPlay.Click += new System.EventHandler(this.buttonPlay_Click);
            // 
            // labelJugador
            // 
            this.labelJugador.AutoSize = true;
            this.labelJugador.Location = new System.Drawing.Point(646, 39);
            this.labelJugador.Name = "labelJugador";
            this.labelJugador.Size = new System.Drawing.Size(0, 13);
            this.labelJugador.TabIndex = 14;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(578, 250);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 13);
            this.label3.TabIndex = 15;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(591, 386);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(118, 42);
            this.button1.TabIndex = 16;
            this.button1.Text = "Reset";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.reset_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.labelJugador);
            this.Controls.Add(this.buttonPlay);
            this.Controls.Add(this.labelMovimientos);
            this.Controls.Add(this.labelTurnos);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.b9);
            this.Controls.Add(this.b8);
            this.Controls.Add(this.b7);
            this.Controls.Add(this.b6);
            this.Controls.Add(this.b5);
            this.Controls.Add(this.b4);
            this.Controls.Add(this.b3);
            this.Controls.Add(this.b2);
            this.Controls.Add(this.b1);
            this.Name = "Form1";
            this.Text = "TaTeTi";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button b1;
        private System.Windows.Forms.Button b2;
        private System.Windows.Forms.Button b3;
        private System.Windows.Forms.Button b4;
        private System.Windows.Forms.Button b5;
        private System.Windows.Forms.Button b6;
        private System.Windows.Forms.Button b7;
        private System.Windows.Forms.Button b8;
        private System.Windows.Forms.Button b9;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelTurnos;
        private System.Windows.Forms.Label labelMovimientos;
        private System.Windows.Forms.Button buttonPlay;
        private System.Windows.Forms.Label labelJugador;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
    }
}

